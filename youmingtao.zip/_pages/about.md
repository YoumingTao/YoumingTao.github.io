---
permalink: /
title: ""
excerpt: ""
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---

<!--
{% if site.google_scholar_stats_use_cdn %}
{% assign gsDataBaseUrl = "https://cdn.jsdelivr.net/gh/" | append: site.repository | append: "@" %}
{% else %}
{% assign gsDataBaseUrl = "https://raw.githubusercontent.com/" | append: site.repository | append: "/" %}
{% endif %}
{% assign url = gsDataBaseUrl | append: "google-scholar-stats/gs_data_shieldsio.json" %}
-->

<span class='anchor' id='about-me'></span>

# About Me

I am a postdoctoral researcher with the [Telecommunication Networks (TKN) Group](https://www.tkn.tu-berlin.de/) at the [School of Electrical Engineering and Computer Science](https://www.tu.berlin/eecs/), [TU Berlin](https://www.tu.berlin/). I completed my PhD under the supervision of [Prof. Dr.-Ing. habil. Falko Dressler](https://www2.tkn.tu-berlin.de/team/dressler/) and [Prof. Xiuzhen (Susan) Cheng](https://scholar.google.com/citations?user=O1yGhH0AAAAJ&hl=en), graduating with *summa cum laude* in 2025. I am also very fortunate to work closely with [Prof. Di Wang](https://shao3wangdi.github.io/), who directs the [PRADA Lab](https://pradalab1.github.io/) at [KAUST](https://www.kaust.edu.sa/en/).

I obtained my bachelor's degree (with distinction) in Computer Science from the [Taishan (Honors) College](https://www.tsxt.sdu.edu.cn/) at [Shandong University](https://www.sdu.edu.cn/) in 2021.

<!-- My most recent cv can be found [here]() -->

# Research 

My research focuses on distributed AI and trustworthy AI, with a particular interest in edge environments.

<!-- My research was supported by the inaugural batch of the National Natural Science Foundation of China's Basic Research Program for Doctoral Students [首批国家自然科学基金博士生项目] and the inaugural batch of the China Association for Science and Technology's Young Talent Support Program – Doctoral Student Special Plan [首批中国科协青年人才托举工程博士生专项计划]. -->

<span style="color: red;">Openings:</span> Motivated students interested in research collaboration are welcome to email me their CV. TU Berlin students interested in related topics are also welcome to contact me about bachelor’s/master’s thesis opportunities.


# Publications  

<p>
&#10033;: equal contribution | <u>underlined names</u>: students I (co-)supervised
</p>

<!--
## Preprints

<li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[Arxiv]</span>
    <div style="display: table-cell; text-align: left;">
      	Second-Order Convergence in Private Stochastic Non-Convex Optimization   
      <br><strong>Youming Tao</strong>, Zuyuan Zhang, Dongxiao Yu, Xiuzhen Cheng, Falko Dressler, Di Wang    
      <br><em><a href="https://arxiv.org/abs/2505.15647v1">arXiv:2505.15647 [cs.LG]</a></em>
    </div>
  </li>
-->

## Peer-Refereed Conference Papers

<ul style="list-style: none; padding-left: 0;">

  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[EMNLP]</span>
    <div style="display: table-cell; text-align: left;">
      FedSubMuon: Communication-Efficient Federated LLM Fine-Tuning via Structured Subspace Muon <a href="">[link]</a>  
      <br> <u>Shaolong Chen</u>, <strong>Youming Tao</strong>, Shuzhen Chen, Falko Dressler, Qingqing Ye, Di Wang  
      <br><em>The 2026 Conference on Empirical Methods in Natural Language Processing (EMNLP 2026 Findings)</em>
    </div>
  </li>

  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[MobiCom]</span>
    <div style="display: table-cell; text-align: left;">
      CRISP: Co-designing Pruning and Scheduling for Efficient MoE Inference on Edge Servers <a href="">[link]</a>  
      <br> Congwei Zhang<sup>&#10033;</sup>, <strong>Youming Tao</strong><sup>&#10033;</sup>, Yifei Zou, Yu Yang, Ruirui Zhang, Xiaoyu Zhang, Falko Dressler, Xiuzhen Cheng, Dongxiao Yu  
      <br><em>The 32nd Annual International Conference on Mobile Computing and Networking (MobiCom 2026)</em>
    </div>
  </li>
  
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[WASA]</span>
    <div style="display: table-cell; text-align: left;">
      Distributed PAC Learning from Quantum Data with Efficient Communication <a href="">[Link]</a>  
      <br> <strong>Youming Tao</strong>, <u>Yaowu Yang</u>, Shuzhen Chen, Huiqun Li, Congwei Zhang, Falko Dressler  
      <br><em>The 20th International Conference on Wireless Artificial Intelligent Computing Systems and Applications (WASA 2026)</em>
      <br><span style="color: red;">Best Paper Award</span>
    </div>
  </li>

  
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[ICML]</span>
    <div style="display: table-cell; text-align: left;">
      Finding Differentially Private Second Order Stationary Points in Stochastic Minimax Optimization <a href="https://arxiv.org/abs/2602.01339">[arxiv]</a> <a href="https://openreview.net/forum?id=st1MolZlTP">[link]</a>  
      <br> <u>Difei Xu</u><sup>&#10033;</sup>, <strong>Youming Tao</strong><sup>&#10033;</sup>, Meng Ding, Chenglin Fan, Di Wang  
      <br><em>The 43rd International Conference on Machine Learning (ICML 2026)</em>
    </div>
  </li>

  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[ICML]</span>
    <div style="display: table-cell; text-align: left;">
      Trajectory-Aware Certified Decentralized Unlearning via SGD Stability <a href="https://openreview.net/forum?id=45Lk9G28L5">[link]</a>  
      <br> <u>Hengliang Wu</u>, Jiale Yang, Shuzhen Chen, Di Wang, Dongxiao Yu, <strong>Youming Tao</strong>    
      <br><em>The 43rd International Conference on Machine Learning (ICML 2026)</em>
    </div>
  </li>

  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[INFOCOM]</span>
    <div style="display: table-cell; text-align: left;">
      Certified Unlearning in Decentralized Federated Learning <a href="https://arxiv.org/abs/2601.06436">[arxiv]</a>  
      <br> <u>Hengliang Wu</u><sup>&#10033;</sup>, <strong>Youming Tao</strong><sup>&#10033;</sup>, Anhao Zhou, Shuzhen Chen, Falko Dressler, Dongxiao Yu  
      <br><em>The 45th IEEE International Conference on Computer Communications (INFOCOM 2026)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[NeurIPS]</span>
    <div style="display: table-cell; text-align: left;">
      Second-Order Convergence in Private Stochastic Non-Convex Optimization <a href="https://arxiv.org/abs/2505.15647">[arxiv]</a> <a href="https://openreview.net/forum?id=VmM8JVwVqV">[link]</a>  
      <br><strong>Youming Tao</strong>, Zuyuan Zhang, Dongxiao Yu, Xiuzhen Cheng, Falko Dressler, Di Wang  
      <br><em>The 39th Annual Conference on Neural Information Processing Systems (NeurIPS 2025)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[MobiArch]</span>
    <div style="display: table-cell; text-align: left;">
      Differentially Private Matroid Bandits for Online Network Topology Optimization <a href="https://dl.acm.org/doi/10.1145/3737897.3767290">[link]</a>   
      <br><strong>Youming Tao</strong>, Shuzhen Chen, Kai Li, Dongxiao Yu, Xiuzhen Cheng, Falko Dressler  
      <br><em>The 20th ACM Workshop on Mobility in the Evolving Internet Architecture (MobiArch 2025), in conjunction with the 31st ACM International Conference on Mobile Computing and Networking (MobiCom 2025)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[ECML]</span>
    <div style="display: table-cell; text-align: left;">
      Differentially Private Sparse Linear Regression with Heavy-tailed Responses <a href="https://arxiv.org/abs/2506.06861">[arxiv]</a> <a href="https://link.springer.com/chapter/10.1007/978-3-032-06096-9_21">[link]</a>  
      <br>Xizhi Tian, Meng Ding, <strong>Youming Tao</strong>, Zihang Xiang, Di Wang  
      <br><em>European Conference on Machine Learning and Principles and Practice of Knowledge Discovery in Databases 2025 (ECML-PKDD 2025)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[COCOON]</span>
    <div style="display: table-cell; text-align: left;">
      Robust Matroid Bandit Optimization against Adversarial Contamination <a href="https://link.springer.com/chapter/10.1007/978-981-96-1090-7_27">[link]</a>  
      <br><strong>Youming Tao</strong>, Xiuzhen Cheng, Falko Dressler, Zhipeng Cai, Dongxiao Yu  
      <br><em>The 30th International Computing and Combinatorics Conference (COCOON 2024)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[ICMC]</span>
    <div style="display: table-cell; text-align: left;">
      <strong>[Invited Paper]</strong> Optimizing Task Migration Decisions in Vehicular Edge Computing Environments <a href="https://ieeexplore.ieee.org/document/11062755">[link]</a>  
      <br>Ziqi Zhou, <strong>Youming Tao</strong>, Agon Memedi, Chunghan Lee, Seyhan Ucar, Onur Altintas, Falko Dressler  
      <br><em>The 1st IEEE International Conference on Meta Computing (ICMC 2024)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[ICNC]</span>
    <div style="display: table-cell; text-align: left;">
      <strong>[Invited Paper]</strong> Correlation-Aware and Personalized Privacy-Preserving Data Collection <a href="https://ieeexplore.ieee.org/document/10556247">[link]</a>  
      <br>Dongxiao Yu, <u>Kaiyi Zhang</u>, <strong>Youming Tao</strong>, Wenlu Xu, Yifei Zou, Xiuzhen Cheng  
      <br><em>International Conference on Computing, Networking and Communication (ICNC 2024)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[VLDB]</span>
    <div style="display: table-cell; text-align: left;">
      Communication Efficient and Provable Federated Unlearning <a href="https://arxiv.org/abs/2401.11018">[arxiv]</a> <a href="https://www.vldb.org/pvldb/vol17/p1119-wang.pdf">[link]</a>  
      <br><strong>Youming Tao</strong><sup>&#10033;</sup>, Cheng-Long Wang<sup>&#10033;</sup>, Miao Pan, Dongxiao Yu, Xiuzhen Cheng, Di Wang  
      <br><em>The 50th International Conference on Very Large Databases (VLDB 2024)</em>
      <br>- Presented as a Hot Topics Talk at International Conference on Networked Systems 2025 (NetSys 2025)
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[NeurIPS]</span>
    <div style="display: table-cell; text-align: left;">
      On Private and Robust Bandits <a href="https://arxiv.org/pdf/2302.02526.pdf">[arxiv]</a> <a href="https://proceedings.neurips.cc/paper_files/paper/2023/hash/6d13e085b79d454da5910e4ca82a3d9d-Abstract-Conference.html">[link]</a>  
      <br>Yulian Wu<sup>&#10033;</sup>, Xingyu Zhou<sup>&#10033;</sup>, <strong>Youming Tao</strong>, Di Wang  
      <br><em>The 37th Annual Conference on Neural Information Processing Systems (NeurIPS 2023)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[IJCAI]</span>
    <div style="display: table-cell; text-align: left;">
      Private Stochastic Convex Optimization and Sparse Learning with Heavy-tailed Data Revisited <a href="https://www.ijcai.org/proceedings/2022/548">[link]</a>  
      <br><strong>Youming Tao</strong>, Yulian Wu, Xiuzhen Cheng, Di Wang  
      <br><em>The 31st International Joint Conference on Artificial Intelligence (IJCAI 2022)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[AISTATS]</span>
    <div style="display: table-cell; text-align: left;">
      Optimal Rates of (Locally) Differentially Private Heavy-tailed Multi-Armed Bandits <a href="https://arxiv.org/abs/2106.02575">[arxiv]</a> <a href="https://proceedings.mlr.press/v151/tao22a.html">[link]</a>  
      <br><strong>Youming Tao</strong><sup>&#10033;</sup>, Yulian Wu<sup>&#10033;</sup>, Peng Zhao, Di Wang  
      <br><em>The 25th International Conference on Artificial Intelligence and Statistics (AISTATS 2022)</em>  
      <br><span style="color: red;">Selected as an Oral paper (Acceptance Rate: 44/1685=2.6%)</span>.  
      <br>- Presented at ICML 2022 Workshop on Responsible Decision Making in Dynamic Environments (ICML-RDMDE 2022)  
      <br><span style="color: red;">Selected as contributed talk.</span>  
      <br>- Presented at CCS 2021 Workshop on Privacy Preserving Machine Learning (CCS-PPML 2022)
    </div>
  </li>
</ul>

## Peer-Refereed Journal Papers

<ul style="list-style: none; padding-left: 0;">
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[TON]</span>
    <div style="display: table-cell; text-align: left;">
      One-Shot Federated Model Editing for Device Dynamics at the Edge <a href="">[link]</a>  
      <br><strong>Youming Tao</strong><sup>&#10033;</sup>, <u>Weijun Yin</u><sup>&#10033;</sup>, Huanyi Xie, Yanqing Yao, Dongxiao Yu, Xiuzhen Cheng, Di Wang, Falko Dressler
      <br><em>IEEE Transactions on Networking (Accepted)</em>  
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[TON]</span>
    <div style="display: table-cell; text-align: left;">
      Byzantine-Resilient Federated Learning under Heterogeneity and Heavy Tails <a href="https://ieeexplore.ieee.org/document/11494133">[link]</a>  
      <br><strong>Youming Tao</strong>, Zuyuan Zhang, Di Wang, Dongxiao Yu, Xiuzhen Cheng, Falko Dressler
      <br><em>IEEE Transactions on Networking (Volume: 34)</em>  
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[TON]</span>
    <div style="display: table-cell; text-align: left;">
      Online Private Adaptive Ranking with Incentive-Based Crowdsensing Data <a href="https://ieeexplore.ieee.org/document/11382030">[link]</a>  
      <br>Shuzhen Chen, Hui Xia, Shulin Zhao, <strong>Youming Tao</strong>, Dongxiao Yu, Xiuzhen Cheng
      <br><em>IEEE Transactions on Networking (Volume: 34)</em>  
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[CJE]</span>
    <div style="display: table-cell; text-align: left;">
      Nearly-Tight Bounds for Private Stochastic Convex Optimization and Sparse Learning under Heavy Tails <a href="https://cje.ejournal.org.cn/article/doi/10.23919/cje.2025.00.225">[link]</a>  
      <br><strong>Youming Tao</strong>, Di Wang, Xiuzhen Cheng
      <br><em>Chinese Journal of Electronics (vol. 35, no. 4)</em>  
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[TCS]</span>
    <div style="display: table-cell; text-align: left;">
      Robust Matroid Bandit Optimization: Near-Optimal Rates under Adversarial Contamination <a href="https://www.sciencedirect.com/science/article/pii/S0304397525003548">[link]</a>  
      <br><strong>Youming Tao</strong>, Xiuzhen Cheng, Falko Dressler, Zhipeng Cai, Dongxiao Yu  
      <br><em>Theoretical Computer Science (Volume 1051, October 2025, 115416)</em>  
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[TCS]</span>
    <div style="display: table-cell; text-align: left;">
      Adaptive pruning-based Newton's method for distributed learning <a href="https://www.sciencedirect.com/science/article/pii/S0304397524006042">[link]</a>  
      <br>Shuzhen Chen, Yuan Yuan, <strong>Youming Tao</strong>, Zhipeng Cai, Dongxiao Yu  
      <br><em>Theoretical Computer Science (Volume 1026, February 2025, 114987)</em>  
      <br><em>A prior version was presented in the 29th International Computing and Combinatorics Conference (COCOON 2023)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[TMC]</span>
    <div style="display: table-cell; text-align: left;">
      Private Over-the-Air Federated Learning at Band-Limited Edge <a href="https://ieeexplore.ieee.org/abstract/document/10552080">[link]</a>  
      <br><strong>Youming Tao</strong>, Shuzhen Chen, Congwei Zhang, Di Wang, Dongxiao Yu, Xiuzhen Cheng, Falko Dressler  
      <br><em>IEEE Transactions on Mobile Computing (Volume: 23, Issue: 12, December 2024)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[TC]</span>
    <div style="display: table-cell; text-align: left;">
      Byzantine-Resilient Federated Learning at Edge <a href="https://arxiv.org/abs/2303.10434">[arxiv]</a> <a href="https://ieeexplore.ieee.org/abstract/document/10070815">[link]</a>  
      <br><strong>Youming Tao</strong>, Sijia Cui, Wenlu Xu, Haofei Yin, Dongxiao Yu, Weifa Liang, Xiuzhen Cheng  
      <br><em>IEEE Transactions on Computers (Volume: 72, Issue: 9, 01 September 2023)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[TKDE]</span>
    <div style="display: table-cell; text-align: left;">
      A Distributed Privacy-Preserving Learning Dynamics in General Social Networks <a href="https://arxiv.org/pdf/2011.09845v2.pdf">[arxiv]</a> <a href="https://ieeexplore.ieee.org/document/10035414">[link]</a>  
      <br><strong>Youming Tao</strong>, Shuzhen Chen, Feng Li, Dongxiao Yu, Jiguo Yu, Hao Sheng  
      <br><em>IEEE Transactions on Knowledge and Data Engineering (Volume: 35, Issue: 9, 01 September 2023)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[TVT]</span>
    <div style="display: table-cell; text-align: left;">
      Decentralized Parallel SGD With Privacy Preservation in Vehicular Networks <a href="https://ieeexplore.ieee.org/abstract/document/9374104">[link]</a>  
      <br>Dongxiao Yu, Zongrui Zou, Shuzhen Chen, <strong>Youming Tao</strong>, Bing Tian, Weifeng Lv, Xiuzhen Cheng  
      <br><em>IEEE Transactions on Vehicular Technology (Volume 70, Issue 6, June 2021)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[JSA]</span>
    <div style="display: table-cell; text-align: left;">
      Distributed Learning Dynamics of Multi-Armed Bandits for Edge Intelligence <a href="https://www.sciencedirect.com/science/article/abs/pii/S1383762120301806">[link]</a>  
      <br>Shuzhen Chen, <strong>Youming Tao</strong>, Dongxiao Yu, FengLi, Bei Gong  
      <br><em>Journal of Systems Architecture (Volume 114, March 2021)</em>
    </div>
  </li>
  <li style="display: table-row; margin-bottom: 10px;">
    <span style="display: table-cell; color: blue; width: 90px; vertical-align: top; text-align: left;">[IOTJ]</span>
    <div style="display: table-cell; text-align: left;">
      Privacy-Preserving Collaborative Learning for Multi-Armed Bandits in IoT <a href="https://ieeexplore.ieee.org/abstract/document/9165854">[link]</a>  
      <br>Shuzhen Chen, <strong>Youming Tao</strong>, Dongxiao Yu, Feng Li, Bei Gong, Xiuzhen Cheng  
      <br><em>IEEE Internet of Things Journal (Volume 8, Issue 5, March 2021)</em>
    </div>
  </li>
</ul>

# Grants & Awards

<ul style="list-style: none; padding-left: 0;">
  <li style="display: table-row; margin-bottom: 8px;">
    <div style="display: table-cell; text-align: left; vertical-align: top;">
      Best Paper Award, The 20th International Conference on Wireless Artificial Intelligent Computing Systems and Applications (WASA 2026)  
    </div>
    <span style="display: table-cell; width: 160px; text-align: right; vertical-align: top;">
      Jun. 2026
    </span>
  </li>

  <li style="display: table-row; margin-bottom: 8px;">
    <div style="display: table-cell; text-align: left; vertical-align: top;">
      National Natural Science Foundation of China (NSFC) Basic Research Program for Doctoral Students  
      <br>[首批国家自然科学基金博士生项目]
    </div>
    <span style="display: table-cell; width: 160px; text-align: right; vertical-align: top;">
      May. 2024 – Dec. 2025
    </span>
  </li>

  <li style="display: table-row; margin-bottom: 8px;">
    <div style="display: table-cell; text-align: left; vertical-align: top;">
      China Association for Science and Technology (CAST)  
      Young Talent Support Program – Doctoral Student Special Plan  
      <br>[首批中国科协青年人才托举工程博士生专项计划]
    </div>
    <span style="display: table-cell; width: 160px; text-align: right; vertical-align: top;">
      Jan. 2025 – Dec. 2025
    </span>
  </li>

  <li style="display: table-row; margin-bottom: 8px;">
    <div style="display: table-cell; text-align: left; vertical-align: top;">
      EurIPS 2025 Student Travel Award
    </div>
    <span style="display: table-cell; width: 160px; text-align: right; vertical-align: top;">
      Oct. 2025
    </span>
  </li>

  <li style="display: table-row; margin-bottom: 8px;">
    <div style="display: table-cell; text-align: left; vertical-align: top;">
      NeurIPS 2025 Student Travel Award
    </div>
    <span style="display: table-cell; width: 160px; text-align: right; vertical-align: top;">
      Oct. 2025
    </span>
  </li>

  <li style="display: table-row; margin-bottom: 8px;">
    <div style="display: table-cell; text-align: left; vertical-align: top;">
      MobiCom 2025 Student Travel Award
    </div>
    <span style="display: table-cell; width: 160px; text-align: right; vertical-align: top;">
      Oct. 2025
    </span>
  </li>

  <li style="display: table-row; margin-bottom: 8px;">
    <div style="display: table-cell; text-align: left; vertical-align: top;">
      National Scholarship of China
    </div>
    <span style="display: table-cell; width: 160px; text-align: right; vertical-align: top;">
      Oct. 2023 &amp; Oct. 2024
    </span>
  </li>
</ul>

# Professional Service
<ul class="service">
  <li>
    <em>Area Chair</em>
    <div class="rows">
      ICLR: <a href="https://iclr.cc/Conferences/2027">2027</a><br>
    </div>
  </li>

  <li>
    <em>(Technical) Program Committee Member</em>
    <div class="rows">
      ICDCS: <a href="https://icdcs2026.icdcs.org/sample-page/technical-committee/"> 2026</a><br>
      IJCAI: <a href="https://2026.ijcai.org/">2026</a><br>
      NeurIPS: <a href="https://neurips.cc/Conferences/2025">2025</a>, <a href="https://neurips.cc/Conferences/2024">2024</a><br>
      ICML: <a href="https://icml.cc/Conferences/2026">2026</a>, <a href="https://icml.cc/Conferences/2025">2025</a><br>
      ICLR: <a href="https://iclr.cc/Conferences/2026">2026</a>, <a href="https://iclr.cc/Conferences/2025">2025</a><br> 
      AISTATS: <a href="https://aistats.org/aistats2026/">2026</a>, <a href="https://aistats.org/aistats2025/index.html">2025</a>, <a href="https://aistats.org/aistats2024/">2024</a><br>
      AAAI: <a href="https://aaai.org/conference/aaai/aaai-27/">2027</a>, <a href="https://aaai.org/conference/aaai/aaai-26/">2026</a>, <a href="https://aaai.org/conference/aaai/aaai-25/">2025</a>, <a href="https://aaai.org/aaai-conference/">2024</a>, <a href="https://aaai.org/Conferences/AAAI-23/">2023</a><br>
      ECML-PKDD: <a href="https://2022.ecmlpkdd.org/">2022</a><br>
      ICASSP: <a href="https://2025.ieeeicassp.org/">2025</a>, <a href="https://2024.ieeeicassp.org/">2024</a><br>
      DLS @ IEEE MASS: <a href="https://bds-sdu.github.io/DLS-2026/#committees">2026</a>, <a href="https://bds-sdu.github.io/DLS-2025/#committees">2025</a><br>
    </div>
  </li>

  <li>
    <em>Conference Session Chair</em>
    <div class="rows">
      INFOCOM <a href="https://infocom2026.ieee-infocom.org/main-technical-program/">2026</a><br>
    </div>
  </li>

  <li>
    <em>Conference external reviewer</em>
    <div class="rows">
      ISIT: <a href="https://2026.ieee-isit.org/">2026</a><br>
      CVPR: <a href="https://cvpr.thecvf.com/Conferences/2024">2024</a><br>
      COLT: <a href="https://learningtheory.org/colt2024/">2024</a><br>
      NeurIPS: <a href="https://nips.cc/Conferences/2023">2023</a><br>
      ICML: <a href="https://icml.cc/Conferences/2023">2023</a><br>
      ICLR: <a href="https://iclr.cc/Conferences/2023">2023</a><br>
      AISTATS: <a href="http://aistats.org/aistats2023/">2023</a><br>
      Euro S&amp;P: <a href="https://www.ieee-security.org/TC/EuroSP2023/">2023</a><br>
      ESORICS: <a href="https://esorics2022.compute.dtu.dk/index.html">2022</a>
    </div>
  </li>

  <li>
    <em>Journal Reviewer</em>
    <div class="rows">
      2024- :<a href="https://sites.google.com/view/ieee-acm-ton/home">IEEE/ACM Transactions on Networking (TON)</a><br>
      2024- :<a href="https://www.comsoc.org/publications/journals/ieee-tmlcn">IEEE Transactions on Machine Learning in Communications and Networking (TMLCN)</a><br>
      2024- :<a href="https://ieeexplore.ieee.org/xpl/RecentIssue.jsp?punumber=10206">IEEE Transactions on Information Forensics &amp; Security (TIFS)</a><br>
      2024- :<a href="https://www.computer.org/csdl/journal/td">IEEE Transactions on Parallel and Distributed Systems (TPDS)</a><br>
      2024- :<a href="https://www.computer.org/csdl/journal/tc">IEEE Transactions on Computers (TC)</a><br>
      2023- :<a href="https://www.computer.org/csdl/journal/tm">IEEE Transactions on Mobile Computing (TMC)</a><br>
      2026- :<a href="https://jmlr.org/tmlr/">Transactions on Machine Learning Research (TMLR)</a><br>
      2025- :<a href="https://dl.acm.org/journal/topml">ACM Transactions on Probabilistic Machine Learning (TOPML)</a><br>
      2024- :<a href="https://www.sciencedirect.com/journal/information-processing-and-management">Elsevier Information Processing &amp; Management (IP&amp;M)</a><br>
      2026- :<a href="https://www.sciencedirect.com/journal/neurocomputing">Elsevier Neurocomputing</a><br>
      2023- :<a href="https://www.springer.com/journal/11704">Springer Frontiers of Computer Science (FCS)</a>

    </div>
  </li>
</ul>

<style>
  /* 让内容和标题左边齐平 */
  .service { margin: 0; padding-left: 1.2em; }          /* 1.2em 控制 bullet 区域宽度 */
  .service li { margin: 0 0 .6em 0; }                   /* 各大项之间统一间距 */
  .service li > em { font-style: italic; }
  .service .rows { margin: .2em 0 0 0; line-height: 1.35; } /* 标题与第一行之间微小间距，避免看起来粘连 */
</style>


<!-- #  Educations
- *2019.06 - 2022.04 (now)*, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus ornare aliquet ipsum, ac tempus justo dapibus sit amet. 
- *2015.09 - 2019.06*, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus ornare aliquet ipsum, ac tempus justo dapibus sit amet. 

# Invited Talks
- *2021.06*, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus ornare aliquet ipsum, ac tempus justo dapibus sit amet. 
- *2021.03*, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus ornare aliquet ipsum, ac tempus justo dapibus sit amet.  \| [\[video\]](https://github.com/)

#  Internships
- *2019.05 - 2020.02*, [Lorem](https://github.com/), China.
-->
